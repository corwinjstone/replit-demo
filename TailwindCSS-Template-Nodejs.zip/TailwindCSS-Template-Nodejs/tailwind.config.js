/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./pages/**/*.{html,js}"],
  mode: 'jit',
  theme: {
    extend: {},
  },
  plugins: [],
}
